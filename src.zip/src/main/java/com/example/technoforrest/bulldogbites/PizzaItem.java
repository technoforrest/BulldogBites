package com.example.technoforrest.bulldogbites;

import java.io.Serializable;

public class PizzaItem extends FoodItem {
    private double price;
    private Boolean glutenBool = false;
    private Boolean sauce = false;
    private Boolean cheese;
    private Boolean pepperoni;
    private Boolean italianSausage;
    private Boolean chicken;
    private Boolean mushrooms;
    private Boolean olives;
    private Boolean greenPeppers;
    private Boolean onions;

    public PizzaItem(){
        this.price = 0.00;
        this.glutenBool = false;
        this.sauce = false;
        this.cheese = false;
        this.pepperoni = false;
        this.italianSausage = false;
        this.chicken = false;
        this.mushrooms = false;
        this.olives = false;
        this.greenPeppers = false;
        this.onions = false;
    }
    public PizzaItem(Boolean GF, Boolean SC, Boolean CH, Boolean PP, Boolean IS, Boolean CK, Boolean MR, Boolean OV, Boolean GP, Boolean ON){
        this.price = 9.99;
        this.glutenBool = GF;
        this.sauce = SC;
        this.cheese = CH;
        this.pepperoni = PP;
        this.italianSausage = IS;
        this.chicken = CK;
        this.mushrooms = MR;
        this.olives = OV;
        this.greenPeppers = GP;
        this.onions = ON;

    }
    double setPrice(){
        if(glutenBool){
            this.price += 3.00;
        } else {
            this.price += 0.00;
        }

        if(sauce)
        {
            this.price += 1.00;
        } else {
            this.price += 0.00;
        }

       /* if(cheese)
        {
            price += 1.00;
        } */

        if(pepperoni)
        {
            this.price += 1.00;
        } else {
            this.price += 0.00;
        }

        if(italianSausage)
        {
            this.price += 1.00;
        } else {
            this.price += 0.00;
        }

        if(chicken)
        {
            this.price += 1.00;
        } else {
            this.price += 0.00;
        }

        if(mushrooms)
        {
            this.price += 0.50;
        } else {
            this.price += 0.00;
        }

        if(olives)
        {
            this.price += 0.50;
        } else {
            this.price += 0.00;
        }

        if(greenPeppers)
        {
            this.price += 0.50;
        } else {
            this.price += 0.00;
        }

        if(onions)
        {
            this.price += 0.50;
        } else {
            this.price += 0.00;
        }

        return this.price;
    }

    double getPrice(){
        return this.price;
    }

}
