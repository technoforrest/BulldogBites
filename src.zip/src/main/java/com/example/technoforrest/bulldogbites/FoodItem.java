package com.example.technoforrest.bulldogbites;

import java.io.Serializable;

/**
 * Created by schwartz on 11/5/17.
 */

public class FoodItem implements Serializable {
}
