package com.example.technoforrest.bulldogbites;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.text.DecimalFormat;

public class PizzaActivity extends AppCompatActivity {
    private Boolean GF;
    private Boolean SC;
    private Boolean CH;
    private Boolean PP;
    private Boolean IS;
    private Boolean CK;
    private Boolean MR;
    private Boolean OV;
    private Boolean GP;
    private Boolean ON;
    private double totalPrice = 0;
    private PizzaItem pizza;

    private String TAG = "PizzaActivity";
    public TextView glutenFreeCalc;
    public TextView sauceCalc;
    public TextView pepperoniCalc;
    public TextView italianSausageCalc;
    public TextView chickenCalc;
    public TextView mushroomsCalc;
    public TextView olivesCalc;
    public TextView greenPeppersCalc;
    public TextView onionsCalc;
    public TextView totalCalc;
    DecimalFormat decimalFormat = new DecimalFormat();


    public double glutenFree = 0.00;
    public double sauce = 0.00;
    public double pepperoni = 0.00;
    public double italianSausage = 0.00;
    public double chicken = 0.00;
    public double mushrooms = 0.00;
    public double olives = 0.00;
    public double greenPeppers = 0.00;
    public double onions = 0.00;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza);

       // total();
    }

    public void total()
    {
        totalCalc = (TextView) findViewById(R.id.totalEdit);
        totalCalc.setText("$" + decimalFormat.format(pizza.getPrice()) + ".00");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // get the menuinflater to inflate our menu
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.pizza_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    private void backFoodMenu(){
        Intent intent = new Intent(this,FoodMenuActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home:
                Log.d(TAG, "onOptionsItemSelected: home");
                backFoodMenu();
                this.finish();
                break;
            case R.id.SaveMenuItem:
                pizza = new PizzaItem(GF, SC, CH, PP, IS, CK, MR, OV, GP, ON);
                Log.d(TAG, "onOptionsItemSelected: save");
                pizza.setPrice();//crashes here, why???
                totalPrice = pizza.getPrice();
                Intent newIntent = new Intent(PizzaActivity.this,MainActivity.class);
                Log.d(TAG, "Price in PizzaActivity" + totalPrice);
                Bundle b = new Bundle();
                b.putSerializable("Total price", totalPrice);
                newIntent.putExtras(b);
                setResult(Activity.RESULT_OK, newIntent);
                this.finish();
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
    public void switchButtonClicked(View view) {
        Switch switchButton = (Switch) view;
        glutenFreeCalc = (TextView) findViewById(R.id.glutenPriceText);
        if (switchButton.isChecked()) {
            GF = true;
            glutenFree = 3.00;
            glutenFreeCalc.setText("$" + decimalFormat.format(glutenFree) + ".00");
        }
        else {
            GF = false;
            glutenFree = 0.00;
            glutenFreeCalc.setText("$" + decimalFormat.format(glutenFree) + ".00");
        }
    }

    public void radiobuttonClicked(View view) {
        boolean radioChecked = ((RadioButton) view).isChecked();
        sauceCalc = (TextView) findViewById(R.id.saucePriceText);

        switch (view.getId()) {
            case R.id.redSauceButton:
                if (radioChecked) {
                    SC = false;
                    sauce = 0.00;
                    sauceCalc.setText("$" + decimalFormat.format(sauce) + ".00");
                }
                break;
            case R.id.whiteSauceButton:
                if (radioChecked) {
                    SC = true;
                    sauce = 1.00;
                    sauceCalc.setText("$" + decimalFormat.format(sauce) + ".00");
                }
        }
    }

    public void onPepperoniCheckboxClicked(View view) {
        CheckBox pepperoniCheck = ((CheckBox) view);
        pepperoniCalc = (TextView) findViewById(R.id.pepperoniPriceText);
        if (pepperoniCheck.isChecked()) {
            PP = true;
            pepperoni = 1.00;
            pepperoniCalc.setText("$" + decimalFormat.format(pepperoni) + ".00");
        } else {
            PP = false;
            pepperoni = 0.0;
            pepperoniCalc.setText("$" + decimalFormat.format(pepperoni) + ".00");
        }
    }

    public void onItalianSausageCheckboxClicked(View view) {
        CheckBox italianSausageCheck = ((CheckBox) view);
        italianSausageCalc = (TextView) findViewById(R.id.italianSausagePriceText);
        if (italianSausageCheck.isChecked()) {
            IS = true;
            italianSausage = 1.00;
            italianSausageCalc.setText("$" + decimalFormat.format(italianSausage) + ".00");
        } else {
            IS = false;
            italianSausage = 0.0;
            italianSausageCalc.setText("$" + decimalFormat.format(italianSausage) + ".00");
        }
    }

    public void onChickenCheckboxClicked(View view) {
        CheckBox chickenCheck = ((CheckBox) view);
        chickenCalc = (TextView) findViewById(R.id.chickenPriceText);
        if (chickenCheck.isChecked()) {
            CK = true;
            chicken = 1.00;
            chickenCalc.setText("$" + decimalFormat.format(chicken) + ".00");
        } else {
            CK = false;
            chicken = 0.0;
            chickenCalc.setText("$" + decimalFormat.format(chicken) + ".00");
        }
    }

    public void onMushroomsCheckboxClicked(View view) {
        CheckBox mushroomsCheck = ((CheckBox) view);
        mushroomsCalc = (TextView) findViewById(R.id.mushroomPriceText);
        if (mushroomsCheck.isChecked()) {
            MR = true;
            mushrooms = 0.50;
            mushroomsCalc.setText("$" + decimalFormat.format(mushrooms) + "0");
        } else {
            MR = false;
            mushroomsCalc.setText("$" + decimalFormat.format(mushrooms) + ".00");
        }
    }

    public void onOlivesCheckboxClicked(View view) {
        CheckBox olivesCheck = ((CheckBox) view);
        olivesCalc = (TextView) findViewById(R.id.olivesPriceText);
        if (olivesCheck.isChecked()) {
            OV = true;
            olives = 0.50;
            olivesCalc.setText("$" + decimalFormat.format(olives) + "0");
        } else {
            OV = false;
            olives = 0.00;
            olivesCalc.setText("$" + decimalFormat.format(olives) + ".00");
        }
    }

    public void onGreenPeppersCheckboxClicked(View view) {
        CheckBox greenPepperCheck = ((CheckBox) view);
        greenPeppersCalc = (TextView) findViewById(R.id.greenPepperPriceText);
        if (greenPepperCheck.isChecked()) {
            GP = true;
            greenPeppers = 0.50;
            greenPeppersCalc.setText("$" + decimalFormat.format(greenPeppers) + "0");
        } else {
            GP = false;
            greenPeppers = 0.0;
            greenPeppersCalc.setText("$" + decimalFormat.format(greenPeppers) + ".00");
        }
    }

    public void onOnionCheckboxClicked(View view) {
        CheckBox onionCheck = ((CheckBox) view);
        onionsCalc = (TextView) findViewById(R.id.onionPriceText);
        if (onionCheck.isChecked()) {
            ON = true;
            onions = 0.50;
            onionsCalc.setText("$" + decimalFormat.format(onions) + "0");
        } else {
            ON = false;
            onions = 0.0;
            onionsCalc.setText("$" + decimalFormat.format(onions) + ".00");
        }
    }


}